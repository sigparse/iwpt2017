The three subfolders include the grammars and fine to coarse mappings used for the experiments.

The grammars are:

	For HRG parsing:
	littlePrinceGrammar.irtg
	
	For CFG parsing:
	wsjGrammar.irtg

	For TAG parsing:
	WSJ_TAGGrammar.irtg

All are in the main grammar format of the Alto tool (https://bitbucket.org/tclup/alto).

The fine to coarse mappings are included as files containing well bracketed expressions, where a bracket
is preceded by a coarse symbol and then lists all the finer symbols it subsumes. The outermost symbol is
only there to create a complete bracketing. Symbols that are not present are ignored. A bracketing:

____(
	A1(
		B1(C1),
		B2(
			C2,
			C3))
	A2(B3(C4))
)

represents a coarse to fine mapping with 3 levels which maps:
C2 --> B2 --> A1
X  --> X --> X
C1 --> B1 --> A1

In wsjGrammar.irtg symbols which are the result of binarization are written as "X>>C3>>...>>C1" where the nonterminals
divided by ">>" are the ones that will be derived from this symbol. These binarization symbols are mapped as:
X>>C3>>...>>C1 --> X>>B2>>...>>B1 --> X>>A1>>...>>A1
	
